﻿Public Class Conexao

    Private cn As SqlClient.SqlConnection

    Public Sub Conectar()
        Try
            cn = New SqlClient.SqlConnection("")

            cn.Open()

        Catch ex As Exception

            Throw ex

        End Try

    End Sub

    Public Sub Fechar()

        Try
            If Not IsNothing(cn) Then

                If cn.State = ConnectionState.Open Then

                    cn.Close()


                End If


            End If


        Catch ex As Exception

        End Try


    End Sub

End Class
