﻿Public Class Form1
    Private banco As New Banco
    Private acoesBanco As New clBancoAcoes

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        Dim Login = TextBox1
        Dim Senha = TextBox2

        Dim retorno As DataTable = acoesBanco.ValidaLogin("select * from usuarios where usuario = '" & Login.Text & "' and senha = '" & Senha.Text & "'")

        If retorno.DefaultView.Count >= 1 Then



            Form2.Show()







        Else
            MessageBox.Show("Usuario ou senha incorretos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If




    End Sub
End Class
