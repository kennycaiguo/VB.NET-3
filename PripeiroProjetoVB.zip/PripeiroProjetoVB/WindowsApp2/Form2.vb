﻿Public Class Form2

    Private banco As New Banco
    Private acoesBanco As New clBancoAcoes

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Consulta.Show()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        acoesBanco.RetornaValor()





    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Cadastrar.Show()

        Close()
    End Sub
End Class