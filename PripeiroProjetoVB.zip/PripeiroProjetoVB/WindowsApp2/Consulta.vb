﻿Imports System.Data.SqlClient

Public Class Consulta
    Private banco As New Banco
    Private acoesBanco As New clBancoAcoes

    Private Sub Button2_Click(sender As Object, e As EventArgs)



    End Sub

    Private Sub Consulta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form2.Close()



        banco.Conectar()

        Dim ds As DataSet = acoesBanco.Consultar("select * from usuarios")

        dgvDados.DataSource = ds.Tables(0)


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Form2.Show()
        Close()

    End Sub

    Private Sub BtnDeletar_Click(sender As Object, e As EventArgs) Handles btnDeletar.Click




        'While (TextBox1.Text = Text) And (TextBox1.Text = "")

        '    MessageBox.Show("Id invalido", "Aviso", MessageBoxButtons.OK)

        'End While


        acoesBanco.Deletar()

        MessageBox.Show("Usuario Deletado com Sucesso", "Aviso", MessageBoxButtons.OK)

        TextBox1.Clear()

        Dim ds As DataSet = acoesBanco.Consultar("select * from usuarios")

        dgvDados.DataSource = ds.Tables(0)





    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class