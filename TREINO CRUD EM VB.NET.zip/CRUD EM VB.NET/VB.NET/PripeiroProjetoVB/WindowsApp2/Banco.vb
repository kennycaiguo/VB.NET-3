﻿Imports System.Data.SqlClient

Public Class Banco

    Public cn As SqlClient.SqlConnection

    Public Sub Conectar()
        Try
            cn = New SqlConnection("Data Source=DESKTOP-4PU8I3U;Initial Catalog=db_teste;User ID=sa;Password=1234567")
            cn.Open()

        Catch ex As Exception

            Throw ex

        End Try


    End Sub

    Public Sub Fechar()

        Try
            If Not IsNothing(cn) Then


                If cn.State = ConnectionState.Open Then
                    cn.Close()

                End If

            End If

        Catch ex As Exception

        End Try

    End Sub



End Class
