﻿Public Class Cadastrar

    Private banco As New clBancoAcoes()

    Private Sub Cadastrar_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form2.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()

        Close()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click




        banco.CadastrarUsu()


    End Sub
End Class