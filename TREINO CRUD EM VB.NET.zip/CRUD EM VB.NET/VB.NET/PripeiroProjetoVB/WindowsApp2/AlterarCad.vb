﻿Public Class AlterarCad

    Private banco As New clBancoAcoes

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim pegaID As Integer



        If Integer.TryParse(TextBox1.Text, pegaID) Then

            banco.BuscaCadastro(pegaID)

        Else

            MessageBox.Show("Valor invalido", "Aviso", MessageBoxButtons.OK)

        End If




    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Form2.Show()

        Close()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim id As Integer = TextBox1.Text
        Dim senha As String = txtSenha.Text
        Dim usuario As String = txtUsu.Text
        Dim nome As String = txtNome.Text


        If senha = txtConfirmaCad.Text Then

            banco.alteraCadastro(id, nome, usuario, senha)

            Dim ds As DataSet = banco.Consultar("select * from usuarios")

            dgvDados.DataSource = ds.Tables(0)

        Else

            MessageBox.Show("As senhas digitadas nao são iguais !", "Avisa", MessageBoxButtons.OK)

        End If



    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDados.CellContentClick

    End Sub

    Private Sub AlterarCad_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        Dim ds As DataSet = banco.Consultar("select * from usuarios")

        dgvDados.DataSource = ds.Tables(0)

    End Sub
End Class