﻿Imports System.Data.SqlClient

Public Class clBancoAcoes

    Private banco As New Banco

    Public Function Consultar(ByVal Comand As String) As DataSet

        banco.Conectar()

        Try
            Dim ds As New DataSet
            Dim adp As New SqlDataAdapter
            Dim objcomand As New SqlCommand

            objcomand = banco.cn.CreateCommand
            objcomand.CommandText = Comand

            adp = New SqlDataAdapter(objcomand)

            adp.Fill(ds)

            Return ds

        Catch ex As Exception

            Throw ex

        End Try

        banco.Fechar()

    End Function


    Public Function ValidaLogin(ByVal comand As String) As DataTable

        banco.Conectar()

        Dim cmd As New SqlCommand
        Dim usuario As New DataTable

        cmd.CommandText = comand
        cmd.Connection = banco.cn


        Dim adp As New SqlDataAdapter(cmd)


        adp.Fill(usuario)





        Return usuario

        banco.Fechar()
    End Function

    Public Sub RetornaValor()


        banco.Conectar()

        Dim cmd As New SqlCommand

        cmd.CommandText = "select * from usuarios where usuario = '" & Form1.TextBox1.Text & "' and senha = '" & Form1.TextBox2.Text & "'"
        cmd.Connection = banco.cn

        Dim dr As SqlDataReader = cmd.ExecuteReader()

        If dr.Read Then

            Form2.Label1.Text = "Olá " & dr("nome")
            Form2.Label2.Text = Date.Now.ToString("dd-mm-yyyy")

        End If


        banco.Fechar()


    End Sub

    Public Sub CadastrarUsu()
        banco.Conectar()


        Dim nome As String = Cadastrar.txtNome.Text
        Dim usuario As String = Cadastrar.txtUsuario.Text
        Dim senha As String = Cadastrar.TxtSenha.Text

        If (senha = Cadastrar.ConfirmaSenha.Text) Then



            Dim cmd As New SqlCommand()
            cmd.Connection = banco.cn



            cmd.CommandText = "insert into usuarios (nome, usuario, senha) values ('" & nome & "', '" & usuario & "', '" & senha & "')"

            'cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = nome
            'cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = usuario
            'cmd.Parameters.Add("@Senha", SqlDbType.VarChar).Value = senha


            cmd.ExecuteNonQuery()



            MessageBox.Show("Usuario Cadastrado com sucesso", "Aviso", MessageBoxButtons.OK)

            Cadastrar.Close()

            Form2.Show()





        Else

            MessageBox.Show("As senhas digitadas nao são iguais !", "Aviso", MessageBoxButtons.OK)




        End If



        banco.Fechar()



    End Sub


    Public Sub Deletar(ByVal id As Integer)

        'Dim id As Integer = Integer.Parse(Consulta.TextBox1.Text)

        Dim cmd As New SqlCommand()
        cmd.Connection = banco.cn



        cmd.CommandText = "Delete usuarios where id = " & ID & ""

        'cmd.Parameters.Add("@nome", SqlDbType.VarChar).Value = nome
        'cmd.Parameters.Add("@usuario", SqlDbType.VarChar).Value = usuario
        'cmd.Parameters.Add("@Senha", SqlDbType.VarChar).Value = senha


        cmd.ExecuteNonQuery()

        banco.Fechar()



    End Sub


    Public Sub BuscaCadastro(ByVal id As Integer)

        Dim CertoID As Integer

        CertoID = id

        banco.Conectar()

        Dim cmd As New SqlCommand

        cmd.CommandText = "select * from usuarios where id = '" & CertoID & "'"
        cmd.Connection = banco.cn

        Dim dr As SqlDataReader = cmd.ExecuteReader()

        If dr.Read Then



            AlterarCad.txtNome.Text = dr("nome").ToString
            AlterarCad.txtSenha.Text = dr("senha").ToString
            AlterarCad.txtUsu.Text = dr("usuario").ToString



        Else




        End If

        banco.Fechar()



    End Sub

    Public Sub alteraCadastro(ByVal id As Integer, ByVal nome As String, ByVal usuario As String, ByVal senha As String)

        banco.Conectar()

        Dim cmd As New SqlCommand
        cmd.Connection = banco.cn
        cmd.CommandText = "update usuarios set nome = '" & nome & "', senha = '" & senha & "', usuario = '" & usuario & "' where id = " & id & ""

        cmd.ExecuteNonQuery()

        banco.Fechar()



    End Sub







End Class
