﻿Public Class clAcoesBanco

End Class
