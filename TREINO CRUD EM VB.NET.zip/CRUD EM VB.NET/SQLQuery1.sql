create database db_teste
go


use db_teste

create table usuarios(

id int primary key identity,
nome varchar (50) ,
usuario varchar (50) unique,
senha varchar (50)

);

select * from usuarios

update usuarios set nome = ' admin2', senha = 'admin3', usuario 'admin2' where id = 6



insert into usuarios (nome, usuario, senha) values('Jhonathan', 'admin', 'admin')