﻿Imports System.Data.SqlClient

Public Class Conexao

    Public cn As New SqlConnection


    Public Sub Conectar()

        Try

            cn.ConnectionString = "Data Source=DESKTOP-RKJ9DQO\SQLEXPRESS;Initial Catalog=DB_ESCOLA;Integrated Security=True"

            cn.Open()

        Catch

            MessageBox.Show("Erro ao se conectar com o banco", "Aviso", MessageBoxButtons.OK)

        End Try



    End Sub

    Public Sub Fechar()

        If cn.State = ConnectionState.Open Then

            cn.Close()

        End If


    End Sub

End Class
