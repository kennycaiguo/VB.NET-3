﻿Public Class Identificacao
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        AlunoLogin.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        DiretorLogin.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        ProfessorLogin.Show()

    End Sub
End Class
