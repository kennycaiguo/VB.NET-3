﻿Public Class mencionarNota

    dim prof as New acoesProf
    Private Sub MencionarNota_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim ds As DataSet = prof.ListaAluno()
        dgvDados.DataSource = ds.Tables(0)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Dim pegaID As Integer

        If Integer.TryParse(txtIdAluno.Text, pegaID) Then

            prof.certoALUNO(pegaID)



        Else

            MessageBox.Show("Valor invalido", "Aviso", MessageBoxButtons.OK)

        End If


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click



        Dim nota1 As Integer = txtIdnota1.Text
        Dim nota2 As Integer = txtnota2.Text
        Dim idAluno As Integer = txtIdAluno.Text



        prof.CadastrarNota(nota1, nota2, idAluno)

        prof.situacaofinal(nota1, nota1, idAluno)

        MessageBox.Show("Nota mencionada com sucesso", "aviso", MessageBoxButtons.OK)

        AreaProf.Show()

        Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        AreaProf.Show()


        Close()

    End Sub

    Private Sub TxtIdAluno_TextChanged(sender As Object, e As EventArgs) Handles txtIdAluno.TextChanged

    End Sub
End Class