﻿Public Class ProfessorLogin

    Dim prof As New acoesProf
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        prof.ValidaLoginProf()

        prof.PegaidProf()

    End Sub
End Class