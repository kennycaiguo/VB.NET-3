﻿Public Class AreaAluno
    Private alunoacoes As New acoesAluno()

    Private Sub AreaAluno_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        Dim ds As DataSet = alunoacoes.AlunoConsulta()

        dgv.DataSource = ds.Tables(0)

        AlunoLogin.Close()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AlunoLogin.Show()
    End Sub
End Class