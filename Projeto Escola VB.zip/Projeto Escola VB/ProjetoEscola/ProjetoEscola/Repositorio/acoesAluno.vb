﻿Imports System.Data.SqlClient






Public Class acoesAluno


    Dim banco As New Conexao
    Dim idAluno As Integer


    Public Sub ValidaLoginAluno()

        banco.Conectar()
        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "SELECT * FROM ALUNO WHERE USUARIO_ALUNO = '" & AlunoLogin.txtUsu.Text & "' and SENHA_ALUNO = '" & AlunoLogin.txtSenha.Text & "'"

        Dim dr As SqlDataReader = cmd.ExecuteReader()

        If dr.Read Then
            AreaAluno.Label1.Text = "Olá Aluno: " & dr("NOME_ALUNO")

            AreaAluno.Show()
        Else

            MessageBox.Show("Usuario ou senha Incorretos", "Aviso", MessageBoxButtons.OK)

        End If


        banco.Fechar()

    End Sub





    Public Sub PegaidAluno()
        banco.Conectar()

        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "Select Id_Aluno from Aluno Where usuario_aluno = '" & AlunoLogin.txtUsu.Text & "' and senha_aluno = '" & AlunoLogin.txtSenha.Text & "'"

        Dim dr As SqlDataReader = cmd.ExecuteReader

        If dr.Read Then

            idAluno = Integer.Parse(dr("id_aluno"))

        End If
        banco.Fechar()

    End Sub

    Public Function AlunoConsulta() As DataSet
        banco.Conectar()
        Dim cmd As New SqlCommand
        Dim adp As New SqlDataAdapter
        Dim ds As New DataSet
        cmd.Connection = banco.cn
        cmd.CommandText = "Select * from aluno where id_aluno = " & idAluno

        adp = New SqlDataAdapter(cmd)

        adp.Fill(ds)


        Return ds

        banco.Fechar()
    End Function




End Class
