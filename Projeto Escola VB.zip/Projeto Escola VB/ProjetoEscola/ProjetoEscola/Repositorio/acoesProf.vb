﻿Imports System.Data.SqlClient

Public Class acoesProf

    Dim banco As New Conexao

    Dim idprof As New Integer

    Public Sub ValidaLoginProf()

        banco.Conectar()
        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "SELECT * FROM PROFESSOR WHERE USUARIO_PROF = '" & ProfessorLogin.txtUsu.Text & "' and SENHA_PROF = '" & ProfessorLogin.txtSenha.Text & "'"

        Dim dr As SqlDataReader = cmd.ExecuteReader()

        If dr.Read Then

            AreaProf.Label1.Text = "Olá Professor: " & dr("NOME_PROF")


            AreaProf.Show()
        Else

            MessageBox.Show("Usuario ou senha Incorretos", "Aviso", MessageBoxButtons.OK)

        End If


        banco.Fechar()

    End Sub

    Public Function PegaidProf()
        banco.Conectar()

        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "Select id_prof from professor Where usuario_prof = '" & ProfessorLogin.txtUsu.Text & "' and senha_prof = '" & ProfessorLogin.txtSenha.Text & "'"

        Dim dr As SqlDataReader = cmd.ExecuteReader

        If dr.Read Then

            Dim idProf As Integer = Integer.Parse(dr("id_prof"))


        End If


        banco.Fechar()

    End Function

    Public Function ListaAluno() As DataSet
        banco.Conectar()

        Dim cmd As New SqlCommand
        Dim adp As New SqlDataAdapter
        Dim ds As New DataSet
        cmd.Connection = banco.cn
        cmd.CommandText = "Select * From Aluno where id_curso = " & idprof

        adp = New SqlDataAdapter(cmd)

        adp.Fill(ds)
        Return ds
        banco.Fechar()

    End Function

    Public Sub certoALUNO(ByVal id As Integer)

        If banco.cn.State = ConnectionState.Closed Then

            banco.Conectar()

        Else

            Dim CertoID As Integer

            CertoID = id

            Dim cmd As New SqlCommand

            cmd.CommandText = "select * from aluno where id_aluno = " & CertoID
            cmd.Connection = banco.cn

            Dim dr As SqlDataReader = cmd.ExecuteReader()

            If dr.Read Then

                mencionarNota.lblNome.Text = dr("nome_aluno").ToString

            Else

                MessageBox.Show("Valor invalido", "Aviso", MessageBoxButtons.OK)


            End If

            banco.Fechar()

        End If

    End Sub

    Public Sub CadastrarNota(ByVal Nota1 As Integer, ByVal Nota2 As Integer, ByVal idAluno As Integer)

        banco.Conectar()
        Dim cmd As New SqlCommand



        cmd.Connection = banco.cn
        cmd.CommandText = "update aluno set nota1 = " & Nota1 & ", nota2 = " & Nota2 & " where id_aluno = " & idAluno


        cmd.ExecuteNonQuery()




        banco.Fechar()

    End Sub


    Public Sub situacaofinal(ByVal Nota1 As Integer, ByVal Nota2 As Integer, ByVal idAluno As Integer)

        banco.Conectar()
        Dim cmd As New SqlCommand

        Dim resultado As Integer = (Nota1 + Nota2) / 2

        cmd.Connection = banco.cn

        If resultado > 5 Then

            cmd.CommandText = "update aluno set situacao = 'Aprovado(a)' where id_aluno = " & idAluno
            cmd.ExecuteNonQuery()




            banco.Fechar()

        Else


            cmd.CommandText = "update aluno set situacao = 'Reprovado' where id_aluno = " & idAluno
            cmd.ExecuteNonQuery()




            banco.Fechar()




        End If







    End Sub









End Class


