﻿Imports System.Data.SqlClient

Public Class acoesDiretor

    Dim banco As New ProjetoEscola.Conexao()

    Public Sub ValidaLoginDiretor()

        banco.Conectar()
        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "SELECT * FROM DIRETOR WHERE USUARIO_DIRETOR = '" & DiretorLogin.txtUsu.Text & "' and SENHA_DIRETOR = '" & DiretorLogin.txtSenha.Text & "'"

        Dim dr As SqlDataReader = cmd.ExecuteReader()

        If dr.Read Then
            AreaDiretor.Label1.Text = "Olá Diretor: " & dr("NOME_DIRETOR")

            AreaDiretor.Show()
        Else

            MessageBox.Show("Usuario ou senha Incorretos", "Aviso", MessageBoxButtons.OK)

        End If


        banco.Fechar()

    End Sub

    Public Sub CadastrarAluno(ByVal id_curso As Integer)

        banco.Conectar()
        Dim cmd As New SqlCommand



        cmd.Connection = banco.cn
        cmd.CommandText = "Insert into aluno (nome_aluno, id_curso, id_cargo, usuario_aluno, senha_aluno) values('" & CadastraAluno.txtNome.Text & "','" & id_curso & "'," & 3 & ",'" & CadastraAluno.txtUsu.Text & "','" & CadastraAluno.txtSenha.Text & "')"


        cmd.ExecuteNonQuery()




        banco.Fechar()

    End Sub

    Public Sub CadastrarProfessor(ByVal id_curso As Integer)

        banco.Conectar()
        Dim cmd As New SqlCommand



        cmd.Connection = banco.cn
        cmd.CommandText = "Insert into professor (nome_prof, id_curso, id_cargo, usuario_prof, senha_prof) values('" & cadastraProfessores.txtNome.Text & "','" & id_curso & "'," & 2 & ",'" & cadastraProfessores.txtUsu.Text & "','" & cadastraProfessores.txtSenha.Text & "')"


        cmd.ExecuteNonQuery()


        banco.Fechar()

    End Sub


    Public Function ListaAluno() As DataSet
        banco.Conectar()

        Dim cmd As New SqlCommand
        Dim adp As New SqlDataAdapter
        Dim ds As New DataSet
        cmd.Connection = banco.cn
        cmd.CommandText = "Select * From Aluno"

        adp = New SqlDataAdapter(cmd)

        adp.Fill(ds)
        Return ds
        banco.Fechar()

    End Function

    Public Function ListaProf() As DataSet

        banco.Conectar()

        Dim cmd As New SqlCommand
        Dim adp As New SqlDataAdapter
        Dim ds As New DataSet
        cmd.Connection = banco.cn
        cmd.CommandText = "Select * From Professor"

        adp = New SqlDataAdapter(cmd)

        adp.Fill(ds)
        Return ds
        banco.Fechar()

    End Function

    Public Sub ExluiAluno(ByVal id As Integer)

        banco.Conectar()
        Dim cmd As New SqlCommand



        cmd.Connection = banco.cn
        cmd.CommandText = "Delete Aluno Where id_aluno = " & id


        cmd.ExecuteNonQuery()


        banco.Fechar()

    End Sub

    Public Sub ExluiProf(ByVal id)

        banco.Conectar()
        Dim cmd As New SqlCommand



        cmd.Connection = banco.cn
        cmd.CommandText = "Delete professor Where id_prof = " & id


        cmd.ExecuteNonQuery()


        banco.Fechar()

    End Sub

    Public Sub BuscaAluno()
        banco.Conectar()
        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "Select * from Aluno Where id_aluno = " & consultaAlunos.txtExcluir.Text

        Dim dr As SqlDataReader = cmd.ExecuteReader

        If dr.Read Then

            ConfirmaExcluirAluno.txtIDaluno.Text = Integer.Parse(dr("id_aluno"))

            ConfirmaExcluirAluno.txtNome.Text = dr("nome_aluno")


        End If

        banco.Fechar()
    End Sub

    Public Sub BuscaProf()
        banco.Conectar()
        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "Select * from professor Where id_prof = " & ConsultaProf.txtExcluir.Text

        Dim dr As SqlDataReader = cmd.ExecuteReader

        If dr.Read Then

            ConfirmaExcluirProf.txtIDaluno.Text = Integer.Parse(dr("id_prof"))
            ConfirmaExcluirProf.txtNome.Text = dr("nome_prof")


        End If

        banco.Fechar()
    End Sub

    Public Sub certoALUNO(ByVal id As Integer)

        If banco.cn.State = ConnectionState.Closed Then

            banco.Conectar()

        Else


            Dim CertoID As Integer

            CertoID = id



            Dim cmd As New SqlCommand

            cmd.CommandText = "select * from aluno where id_aluno = " & CertoID
            cmd.Connection = banco.cn

            Dim dr As SqlDataReader = cmd.ExecuteReader()

            If dr.Read Then



                AlteraAluno.txtNome.Text = dr("nome_aluno").ToString
                AlteraAluno.txtSitu.Text = dr("situacao").ToString
                AlteraAluno.txtIdCurso.Text = dr("id_curso").ToString




            Else

                MessageBox.Show("Valor invalido", "Aviso", MessageBoxButtons.OK)


            End If

            banco.Fechar()

        End If





    End Sub

    Public Sub alterarAluno(ByVal nome As String, ByVal situacao As String, ByVal id_curso As Integer, ByVal id As Integer)


        banco.Conectar()

        Dim cmd As New SqlCommand
        cmd.Connection = banco.cn
        cmd.CommandText = "update aluno set nome_aluno = '" & nome & "', situacao = '" & situacao & "', id_curso = '" & id_curso & "' where id_aluno = " & id & ""

        cmd.ExecuteNonQuery()

        banco.Fechar()



    End Sub

    Public Sub certoProf(ByVal id As Integer)

        If banco.cn.State = ConnectionState.Closed Then

            banco.Conectar()

        Else


            Dim CertoID As Integer

            CertoID = id



            Dim cmd As New SqlCommand

            cmd.CommandText = "select * from aluno where id_aluno = " & CertoID
            cmd.Connection = banco.cn

            Dim dr As SqlDataReader = cmd.ExecuteReader()

            If dr.Read Then

                AlteraProf.txtNome.Text = dr("nome_aluno").ToString
                AlteraProf.txtIdCurso.Text = dr("id_curso").ToString


            Else

                MessageBox.Show("Valor invalido", "Aviso", MessageBoxButtons.OK)


            End If

            banco.Fechar()

        End If





    End Sub

    Public Sub alterarProf(ByVal nome As String, ByVal id_curso As Integer, ByVal id As Integer)


        banco.Conectar()

        Dim cmd As New SqlCommand
        cmd.Connection = banco.cn
        cmd.CommandText = "update aluno set nome_aluno = '" & nome & "', id_curso = '" & id_curso & "' where id_aluno = " & id

        cmd.ExecuteNonQuery()

        banco.Fechar()



    End Sub

    Public Sub VerificaAluno()
        banco.Conectar()
        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "Select * from Aluno Where usuario_aluno = '" & CadastraAluno.txtUsu.Text & "'"

        Dim dr As SqlDataReader = cmd.ExecuteReader

        If dr.Read Then

            CadastraAluno.verificacad.Text = "Existe"

        Else

            CadastraAluno.verificacad.Text = "Valido"

        End If

        banco.Fechar()
    End Sub

    Public Sub VerificaProf()
        banco.Conectar()
        Dim cmd As New SqlCommand


        cmd.Connection = banco.cn
        cmd.CommandText = "Select * from professor Where usuario_prof = '" & cadastraProfessores.txtUsu.Text & "'"

        Dim dr As SqlDataReader = cmd.ExecuteReader

        If dr.Read Then

            cadastraProfessores.verificacad.Text = "Existe"

        Else

            cadastraProfessores.verificacad.Text = "Valido"

        End If

        banco.Fechar()
    End Sub


End Class

