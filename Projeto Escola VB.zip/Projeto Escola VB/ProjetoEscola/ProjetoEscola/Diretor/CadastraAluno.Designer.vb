﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CadastraAluno
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtNome = New System.Windows.Forms.TextBox()
        Me.txtIdCURSO = New System.Windows.Forms.TextBox()
        Me.txtUsu = New System.Windows.Forms.TextBox()
        Me.txtSenha = New System.Windows.Forms.TextBox()
        Me.txtConfirmaSenha = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnCadastrar = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.verificacad = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(39, 118)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nome do aluno"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(39, 267)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Senha"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(39, 222)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Usuario"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(39, 309)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Confirmar Senha"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(39, 171)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(162, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Id do curso que deseja cadastrar"
        '
        'txtNome
        '
        Me.txtNome.Location = New System.Drawing.Point(273, 115)
        Me.txtNome.Name = "txtNome"
        Me.txtNome.Size = New System.Drawing.Size(228, 20)
        Me.txtNome.TabIndex = 5
        '
        'txtIdCURSO
        '
        Me.txtIdCURSO.Location = New System.Drawing.Point(273, 168)
        Me.txtIdCURSO.Name = "txtIdCURSO"
        Me.txtIdCURSO.Size = New System.Drawing.Size(228, 20)
        Me.txtIdCURSO.TabIndex = 6
        '
        'txtUsu
        '
        Me.txtUsu.Location = New System.Drawing.Point(273, 219)
        Me.txtUsu.Name = "txtUsu"
        Me.txtUsu.Size = New System.Drawing.Size(228, 20)
        Me.txtUsu.TabIndex = 7
        '
        'txtSenha
        '
        Me.txtSenha.Location = New System.Drawing.Point(273, 264)
        Me.txtSenha.Name = "txtSenha"
        Me.txtSenha.Size = New System.Drawing.Size(228, 20)
        Me.txtSenha.TabIndex = 8
        '
        'txtConfirmaSenha
        '
        Me.txtConfirmaSenha.Location = New System.Drawing.Point(273, 306)
        Me.txtConfirmaSenha.Name = "txtConfirmaSenha"
        Me.txtConfirmaSenha.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConfirmaSenha.Size = New System.Drawing.Size(228, 20)
        Me.txtConfirmaSenha.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(297, 21)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(268, 26)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "CADASTRO DE ALUNOS"
        '
        'btnCadastrar
        '
        Me.btnCadastrar.Location = New System.Drawing.Point(386, 350)
        Me.btnCadastrar.Name = "btnCadastrar"
        Me.btnCadastrar.Size = New System.Drawing.Size(179, 35)
        Me.btnCadastrar.TabIndex = 11
        Me.btnCadastrar.Text = "Cadastrar"
        Me.btnCadastrar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 403)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(179, 35)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "Voltar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(665, 69)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(92, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "ID DOS CURSOS"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(665, 115)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "ID ""1"" = Informática"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(665, 156)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 13)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "ID "" 2 "" = Administração"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(665, 193)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(109, 13)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "ID "" 3 "" = Engenharia"
        '
        'verificacad
        '
        Me.verificacad.AutoSize = True
        Me.verificacad.Location = New System.Drawing.Point(507, 222)
        Me.verificacad.Name = "verificacad"
        Me.verificacad.Size = New System.Drawing.Size(0, 13)
        Me.verificacad.TabIndex = 17
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(571, 214)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(54, 28)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "Verificar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'CadastraAluno
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.verificacad)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnCadastrar)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtConfirmaSenha)
        Me.Controls.Add(Me.txtSenha)
        Me.Controls.Add(Me.txtUsu)
        Me.Controls.Add(Me.txtIdCURSO)
        Me.Controls.Add(Me.txtNome)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "CadastraAluno"
        Me.Text = "CadastraAluno"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtNome As TextBox
    Friend WithEvents txtIdCURSO As TextBox
    Friend WithEvents txtUsu As TextBox
    Friend WithEvents txtSenha As TextBox
    Friend WithEvents txtConfirmaSenha As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btnCadastrar As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents verificacad As Label
    Friend WithEvents Button1 As Button
End Class
