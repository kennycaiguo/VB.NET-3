﻿Public Class AlteraAluno

    Dim banco As New Conexao
    Dim Diretor As New acoesDiretor
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Dim pegaID As Integer

        If Integer.TryParse(txtIdAluno.Text, pegaID) Then

            Diretor.certoALUNO(pegaID)



        Else

            MessageBox.Show("Valor invalido", "Aviso", MessageBoxButtons.OK)

        End If



    End Sub

    Private Sub DgvDados_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvDados.CellContentClick

    End Sub

    Private Sub AlteraAluno_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Dim ds As DataSet = Diretor.ListaAluno()

        dgvDados.DataSource = ds.Tables(0)



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        consultaAlunos.Show()

        Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim nome As String = txtNome.Text
        Dim situacao As String = txtSitu.Text
        Dim id_curso As String = txtIdCurso.Text
        Dim id As String = txtIdAluno.Text

        If nome = "" And id = "" And txtIdCurso.Text = "" Then

            MessageBox.Show("Preencha todo o Formulario", "Aviso", MessageBoxButtons.OK)

        Else
            Try


                Diretor.alterarAluno(nome, situacao, id_curso, id)

                    MessageBox.Show("Aluno Alterado com Sucesso", "Aviso", MessageBoxButtons.OK)

                    consultaAlunos.Show()

                    Close()

            Catch

                MessageBox.Show("Id Invalido", "Aviso", MessageBoxButtons.OK)

            End Try

        End If




    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub TxtSitu_TextChanged(sender As Object, e As EventArgs) Handles txtSitu.TextChanged

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub TxtNome_TextChanged(sender As Object, e As EventArgs) Handles txtNome.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub TxtIdCurso_TextChanged(sender As Object, e As EventArgs) Handles txtIdCurso.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TxtIdAluno_TextChanged(sender As Object, e As EventArgs) Handles txtIdAluno.TextChanged

    End Sub
End Class