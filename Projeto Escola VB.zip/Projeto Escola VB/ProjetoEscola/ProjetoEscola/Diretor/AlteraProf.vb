﻿Public Class AlteraProf


    Dim diretor As New acoesDiretor
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim pegaID As Integer

        If Integer.TryParse(txtIdProf.Text, pegaID) Then

            diretor.certoProf(pegaID)



        Else

            MessageBox.Show("Valor invalido", "Aviso", MessageBoxButtons.OK)

        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click


        Dim nome As String = txtNome.Text

        Dim id_curso As String = txtIdCurso.Text
        Dim id As String = txtIdProf.Text

        If nome = "" And id = "" And txtIdCurso.Text = "" Then

            MessageBox.Show("Preencha todo o Formulario", "Aviso", MessageBoxButtons.OK)

        Else
            Try


                diretor.alterarProf(nome, id_curso, id)

                MessageBox.Show("Professor Alterado com Sucesso", "Aviso", MessageBoxButtons.OK)

                ConsultaProf.Show()

                Close()

            Catch

                MessageBox.Show("Id Invalido", "Aviso", MessageBoxButtons.OK)

            End Try

        End If



    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub AlteraProf_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim ds As DataSet = diretor.ListaProf()

        dgvDados.DataSource = ds.Tables(0)


    End Sub

    Private Sub TxtIdCurso_TextChanged(sender As Object, e As EventArgs) Handles txtIdCurso.TextChanged

    End Sub

    Private Sub TxtIdProf_TextChanged(sender As Object, e As EventArgs) Handles txtIdProf.TextChanged

    End Sub
End Class