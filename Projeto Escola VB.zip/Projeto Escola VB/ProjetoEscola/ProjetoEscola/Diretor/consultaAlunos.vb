﻿Public Class consultaAlunos

    Dim diretor As New acoesDiretor()
    Private Sub ConsultaAlunos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim ds As DataSet = diretor.ListaAluno()

        dgv.DataSource = ds.Tables(0)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        If Integer.Parse(txtExcluir.Text) Then

            ConfirmaExcluirAluno.Show()

        Else

            MessageBox.Show("Valor Invalido", "Aviso", MessageBoxButtons.OK)

        End If




    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AreaDiretor.Show()
        Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        AlteraAluno.Show()

        Close()
    End Sub
End Class