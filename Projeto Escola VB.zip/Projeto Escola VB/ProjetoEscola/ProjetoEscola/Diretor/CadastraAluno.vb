﻿Public Class CadastraAluno

    Dim diretor As New acoesDiretor
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCadastrar.Click




        If txtNome.Text = "" And txtIdCURSO.Text = "" And txtSenha.Text = "" And txtUsu.Text = "" And txtConfirmaSenha.Text = "" Then

            MessageBox.Show("Preencha todo o formulario", "Aviso", MessageBoxButtons.OK)


        Else

            Try

                Dim id As New Integer
                id = Integer.Parse(txtIdCURSO.Text)


                If Not id = 3 And id = 1 And id = 2 Then

                    MessageBox.Show("Id do curso Invalido", "Aviso", MessageBoxButtons.OK)


                Else


                    If Not txtSenha.Text = txtConfirmaSenha.Text And txtSenha.Text = "" Then


                        MessageBox.Show("As senhas são diferentes !", "Aviso", MessageBoxButtons.OK)

                    Else


                        diretor.CadastrarAluno(id)

                        MessageBox.Show("Cadastro Realizado com Sucesso", "Aviso", MessageBoxButtons.OK)

                        AreaDiretor.Show()

                        Close()


                    End If


                End If

            Catch

                MessageBox.Show("Id do curso Invalido, ou Usuario ja Cadastrado", "Aviso", MessageBoxButtons.OK)

            End Try



        End If




    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AreaDiretor.Show()


        Close()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub CadastraAluno_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TxtUsu_TextChanged(sender As Object, e As EventArgs) Handles txtUsu.TextChanged




    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        diretor.VerificaAluno()
    End Sub
End Class