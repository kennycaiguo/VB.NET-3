﻿Public Class cadastraProfessores
    Dim banco As New Conexao


    Dim diretor As New acoesDiretor

    Private Sub CadastraProfessores_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)


        Close()
    End Sub

    Private Sub BtnCadastrar_Click_1(sender As Object, e As EventArgs) Handles btnCadastrar.Click

        If banco.cn.State = ConnectionState.Closed Then

        Else

            banco.Conectar()

        End If

        If txtNome.Text = "" And txtIdCURSO.Text = "" And txtSenha.Text = "" And txtUsu.Text = "" And txtConfirmaSenha.Text = "" Then

            MessageBox.Show("Preencha todo o formulario", "Aviso", MessageBoxButtons.OK)


        Else

            Try

                Dim id As New Integer
                id = Integer.Parse(txtIdCURSO.Text)


                If Not id = 3 And id = 1 And id = 2 Then

                    MessageBox.Show("Id do curso Invalido", "Aviso", MessageBoxButtons.OK)


                Else


                    If Not txtSenha.Text = txtConfirmaSenha.Text And txtSenha.Text = "" Then


                        MessageBox.Show("As senhas são diferentes !", "Aviso", MessageBoxButtons.OK)

                    Else


                        diretor.CadastrarProfessor(id)

                        MessageBox.Show("Cadastro Realizado com Sucesso", "Aviso", MessageBoxButtons.OK)


                        Close()


                    End If


                End If

            Catch

                MessageBox.Show("Id do curso Invalido, ou Usuario ja Cadastrado", "Aviso", MessageBoxButtons.OK)

            End Try



        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        diretor.VerificaProf()

    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        AreaDiretor.Show()


        Close()
    End Sub
End Class