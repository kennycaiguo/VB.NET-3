﻿Public Class ConsultaProf

    Dim diretor As New acoesDiretor()
    Private Sub ConsultaProf_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Dim ds As DataSet = diretor.ListaProf()

        dgv.DataSource = ds.Tables(0)


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Try



            If Integer.Parse(txtExcluir.Text) Then

                ConfirmaExcluirProf.Show()

            Else

                MessageBox.Show("Valor Invalido", "Aviso", MessageBoxButtons.OK)

            End If

        Catch

            MessageBox.Show("Digite um valor", "Aviso", MessageBoxButtons.OK)

        End Try



    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AreaDiretor.Show()

        Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        AlteraProf.Show()


    End Sub
End Class