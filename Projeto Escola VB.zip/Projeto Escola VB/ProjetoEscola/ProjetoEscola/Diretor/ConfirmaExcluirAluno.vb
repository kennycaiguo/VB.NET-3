﻿Public Class ConfirmaExcluirAluno

    Dim diretor As New acoesDiretor
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        diretor.ExluiAluno(txtIDaluno.Text)
        MessageBox.Show("Aluno excluido com sucesso", "Aviso", MessageBoxButtons.OK)
        Close()

    End Sub

    Private Sub TxtIDaluno_Click(sender As Object, e As EventArgs) Handles txtIDaluno.Click

    End Sub

    Private Sub TxtNome_Click(sender As Object, e As EventArgs) Handles txtNome.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub ConfirmaExcluirAluno_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        diretor.BuscaAluno()

    End Sub
End Class