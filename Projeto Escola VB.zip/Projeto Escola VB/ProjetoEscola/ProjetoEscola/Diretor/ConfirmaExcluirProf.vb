﻿Public Class ConfirmaExcluirProf

    Dim diretor As New acoesDiretor
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        diretor.ExluiProf(txtIDaluno.Text)
        MessageBox.Show("Professor excluido com sucesso", "Aviso", MessageBoxButtons.OK)
        Close()


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub ConfirmaExcluirProf_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        diretor.BuscaProf()
    End Sub
End Class