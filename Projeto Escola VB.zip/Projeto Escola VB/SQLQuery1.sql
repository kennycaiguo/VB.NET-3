CREATE DATABASE DB_ESCOLA
GO

USE DB_ESCOLA
go


CREATE TABLE CARGO (
ID_CARGO INT PRIMARY KEY IDENTITY,
NOME_CARGO VARCHAR(50),
)
GO

CREATE TABLE CURSO (
ID_CURSO INT PRIMARY KEY IDENTITY,
NOME_CURSO VARCHAR(50),
)
GO

CREATE TABLE DIRETOR (
ID_DIRETOR INT PRIMARY KEY IDENTITY,
ID_CARGO INT,
NOME_DIRETOR VARCHAR(50),
USUARIO_DIRETOR VARCHAR(50) unique ,
SENHA_DIRETOR VARCHAR(50),
FOREIGN KEY (ID_CARGO) REFERENCES CARGO (ID_CARGO)
)
GO

CREATE TABLE PROFESSOR (
ID_PROF INT PRIMARY KEY IDENTITY,
ID_CARGO INT,
ID_CURSO INT,
NOME_PROF VARCHAR(50),
USUARIO_PROF VARCHAR(50) unique ,
SENHA_PROF VARCHAR(50),
FOREIGN KEY (ID_CARGO) REFERENCES CARGO (ID_CARGO),
FOREIGN KEY (ID_CURSO) REFERENCES CURSO (ID_CURSO)
)
GO


CREATE TABLE ALUNO (
ID_ALUNO INT PRIMARY KEY IDENTITY,
ID_CARGO INT,
ID_CURSO INT,
NOME_ALUNO VARCHAR(50),
NOTA1 int,
NOTA2 int,
SITUACAO VARCHAR (20),
USUARIO_ALUNO VARCHAR(50) unique ,
SENHA_ALUNO VARCHAR(50),
FOREIGN KEY (ID_CARGO) REFERENCES CARGO (ID_CARGO),
FOREIGN KEY (ID_CURSO) REFERENCES CURSO (ID_CURSO)
)
GO



alter table aluno alter column SITUACAO VARCHAR (20)
GO


insert into curso (NOME_CURSO) values ('Inform�tica')
GO
insert into curso (NOME_CURSO) values ('Administra��o')
GO
insert into curso (NOME_CURSO) values ('Engenharia')
GO



insert into CARGO(NOME_CARGO) values ('Diretor')
GO
insert into CARGO(NOME_CARGO) values ('Professor')
GO
insert into CARGO(NOME_CARGO) values ('Aluno')
GO

insert into diretor (id_cargo, nome_diretor, usuario_diretor, senha_diretor) values (1, 'jhonathan', 'admin','admin')
go


update aluno set nota1 = 10, nota2 = 10 where id_aluno = 1



Select id_prof from professor Where usuario_prof = 'admin' and senha_prof = 'admin'

Insert into aluno (nota1 , nota2) values(10,10), where id = 1

update aluno set nome_aluno = 'robson', situacao = 'reprovado', id_curso = '2' where id_aluno = 1
go




